# Gabriel Drozdov
# Data Narratives
# Final Project: Exploring the GeoCities data dump
# Data Source: https://archive.org/details/geocities-webarchive-collection-derivatives
# Alternate Data Source (not used): https://thepiratebay.org/description.php?id=5923737

require('tidyverse')
options(scipen=999)


# ——————————————————————————————————————————————————————————————————————————————
# ——————————————————————————————————————————————————————————————————————————————
# LOOKING AT THE DATA

# I would NOT recommend loading all of these in at once unless you have plenty of RAM!

# Files not downlaoded (due to size):
# — geocities-html-information.csv.gz / 195.0 GB compressed, probably 1TB or more uncompressed
# — geocities-web-pages.csv.gz / 64.8 GB compressed, probably 500GB or so uncompressed
# ——————————————————————————————————————————————————————————————————————————————
# ——————————————————————————————————————————————————————————————————————————————


# —————————————————————————————————
# SINGLE FILE CSVs
# —————————————————————————————————

# URLs to audio files
audioInformation <- read_csv('derivatives/geocities-audio-information.csv')

# CSS code links, not the code itself but the URLs to the code
cssInformation <- read_csv('derivatives/geocities-css-information.csv')

# Most common domain names referenced?
domainFrequency <- read_csv('derivatives/geocities-domain-frequency.csv')

# Not sure what this is, but features "source", "target", and "count" columns
domainGraph <- read_csv('derivatives/geocities-domain-graph.csv')

# The actual JavaScript code used on websites
# relevant columns: "url", "filename", "content"
jsInformation <- read_csv('derivatives/geocities-js-information.csv')

# Seems to be returned JSON files from running various APIs
jsonInformation <- read_csv('derivatives/geocities-json-information.csv')

# URLs to PDF files 
pdfInformation <- read_csv('derivatives/geocities-pdf-information.csv')

# URLs to plain text files, and the content of those files directly!
# relevant columns: "url", "filename", "content"
plainText <- read_csv('derivatives/geocities-plain-text.csv')

# Basically just links to PowerPoints
presentationProgramInformation <- read_csv('derivatives/geocities-presentation-program-information.csv')

# .csv and .xls file URLs
spreadsheetInformation <- read_csv('derivatives/geocities-spreadsheet-information.csv')

# URLs to video files
videoInformation <- read_csv('derivatives/geocities-video-information.csv')

# Various text document format URLs
wordProcessorInformation <- read_csv('derivatives/geocities-word-processor-information.csv')

# Actual XML code, although exact purpose is unknown
xmlInformation <- read_csv('derivatives/geocities-xml-information.csv')


# —————————————————————————————————
# SPLIT CSVs

# The following files were too large to be one file
# They are split into multiple CSVs of 10mil lines each
# These are just the first .csv files in each group

# NOTE: the second .csv and onwards in each folder have incorrect headers and must be corrected
# —————————————————————————————————

# "source" for page the image is on
# "url" for where the image file lives
# "alt_text" for image alt text attribute
imagegraph <- read_csv('derivatives/imagegraph/imagegraph0.csv')

# URLs to images across all sites
imageInformation <- read_csv('derivatives/image-information/image-information0.csv')

# "source" for page the link is on
# "target" for the link destination
# "anchor_text" for the visible text on the link
webgraph <- read_csv('derivatives/webgraph/webgraph0.csv')

# Random sample of data for website homepage
write_csv(drop_na(sample_n(webgraph, 10000)), "random-links.csv")



# ——————————————————————————————————————————————————————————————————————————————
# ——————————————————————————————————————————————————————————————————————————————
# EXPLORATION 1:
# ASSET EXPLORATIONS

# What were the most used files across different GeoCities sites?
# ——————————————————————————————————————————————————————————————————————————————
# ——————————————————————————————————————————————————————————————————————————————


# —————————————————————————————————
# AUDIO
# —————————————————————————————————
audioExploration1 <- audioInformation %>%
  group_by(filename) %>%
  summarize(total = n()) %>%
  arrange(-total)
audioExploration1Chart <- head(audioExploration1, 50) %>%
  ggplot(aes(x = total, y = fct_reorder(filename, total))) +
  geom_col()
audioExploration1Chart
# Lovely result, so many reused assets including the Titanic theme, Imagine, Friends

write_csv(head(audioExploration1, 50), "audio-files.csv")

# What is CoolPage.wav?
# https://web.archive.org/web/20091020074939/http://geocities.com/wxw_fed2000/CoolPage.wav

# Easy access to MIDI files
specificAudioFile <- audioInformation %>%
  filter(filename == '01.mid') %>%
  select(url, filename)
specificAudioFile

# —————————————————————————————————
# PDFs
# —————————————————————————————————
pdfExploration1 <- pdfInformation %>%
  group_by(filename) %>%
  summarize(total = n()) %>%
  arrange(-total)
pdfExploration1Chart <- head(pdfExploration1, 100) %>%
  ggplot(aes(x = total, y = fct_reorder(filename, total))) +
  geom_col()
pdfExploration1Chart

# index.php is skewing the results. What is it?
pdfExploration1a <- pdfInformation %>%
  filter(filename == 'index.php')
pdfExploration1a
# Looking at preserved URLs on the Internet Archive, the data for these files is all over the place

# Let’s do the same thing without index.php
pdfExploration1b <- pdfInformation %>%
  group_by(filename) %>%
  filter(filename != 'index.php') %>%
  summarize(total = n()) %>%
  arrange(-total)
pdfExploration1bChart <- head(pdfExploration1b, 100) %>%
  ggplot(aes(x = total, y = fct_reorder(filename, total))) +
  geom_col()
pdfExploration1bChart
# Things that stand out:
# — resume.pdf could be really fun to look at!
# — Also newsletter.pdf
# — whatischurch.pdf
# — Someone named Stefan Neumann has a bunch of PDFs
# — Also, quite a few PDFs named after instruments (e.g. ViolinI.pdf)


# —————————————————————————————————
# VIDEOS
# —————————————————————————————————
videoExploration1 <- videoInformation %>%
  group_by(filename) %>%
  summarize(total = n()) %>%
  arrange(-total)
videoExploration1Chart <- head(videoExploration1, 100) %>%
  ggplot(aes(x = total, y = fct_reorder(filename, total))) +
  geom_col()
videoExploration1Chart
# Very few shared video files except for numbered ones (e.g. 2.wmv)


# —————————————————————————————————
# PRESENTATIONS
# —————————————————————————————————
presentationExploration1 <- presentationProgramInformation %>%
  group_by(filename) %>%
  summarize(total = n()) %>%
  arrange(-total)
presentationExploration1Chart <- head(presentationExploration1, 100) %>%
  ggplot(aes(x = total, y = fct_reorder(filename, total))) +
  geom_col()
presentationExploration1Chart
# People need to name their files better, most of these are just called presentation.ppt


# —————————————————————————————————
# SPREADSHEETS
# —————————————————————————————————
spreadsheetExploration1 <- spreadsheetInformation %>%
  group_by(filename) %>%
  summarize(total = n()) %>%
  arrange(-total)
spreadsheetExploration1Chart <- head(spreadsheetExploration1, 100) %>%
  ggplot(aes(x = total, y = fct_reorder(filename, total))) +
  geom_col()
spreadsheetExploration1Chart
# Some interesting results! "heart_rate.xls" stands out

# What about just .csv files?
spreadsheetExploration1b <- spreadsheetInformation %>%
  filter(extension == "csv") %>%
  group_by(filename) %>%
  summarize(total = n()) %>%
  arrange(-total)
spreadsheetExploration1bChart <- head(spreadsheetExploration1b, 100) %>%
  ggplot(aes(x = total, y = fct_reorder(filename, total))) +
  geom_col()
spreadsheetExploration1bChart
# Not much to look at, but form_results.csv seems like it could be something!
# Nevermind it’s mega boring: https://web.archive.org/web/20091028144432/http://geocities.com/meogto82/_private/_vti_cnf/form_results.csv


# ——————————————————————————————————————————————————————————————————————————————
# ——————————————————————————————————————————————————————————————————————————————
# EXPLORATION 2:
# IMAGE ASSET EXPLORATIONS

# Disclaimer:
# I’m technically doing this exploration after Exploration 3
# It made sense to list it before Exploration 3 though since it follows the same inquiry as Exploration 1

# Main objective:
# Find a way to run through multiple .csv files programmatically and track results
# 2a. How many rows are we working with in total?
# 2b. How many unique images are there? (just looking at filename)
# 2c. What are the most commonly used images?
# 2d. What are the breakdowns for different image formats overall?
# 2e. Track image dimensions without any filename info (could make a cool visual!)
# ——————————————————————————————————————————————————————————————————————————————
# ——————————————————————————————————————————————————————————————————————————————


# Track the start time
startTime <- Sys.time()

# Initialize tracking variables
totalRows <- 0
uniqueFiles <- 0
mostUsedImages <- data.frame(filename = character(),
                             extension = character(),
                             total = integer())
mostUsedExtension <- data.frame(extension = character(),
                                total = integer())
mostUsedDimensions <- data.frame(width = double(),
                                 height = double(),
                                 total = integer())

for (x in 0:12) {
  # Read the next relevant .csv file (135 total)
  filename <- paste("derivatives/image-information/image-information", x, ".csv", sep="")
  print(filename)
  imageInformation <- read_csv(filename)
  
  if (x > 0) {
    # For .csv file after 0, the column names are wrong
    
    # Step 1: create temp data frame with just column names to preserve data
    preservedData <- colnames(imageInformation)
    temp <- data.frame(crawl_date = preservedData[1],
                       last_modified_date = preservedData[2],
                       url = preservedData[3],
                       filename = preservedData[4],
                       extension = preservedData[5],
                       mime_type_web_server = preservedData[6],
                       mime_type_tika = preservedData[7],
                       width = preservedData[8],
                       height = preservedData[9],
                       md5 = preservedData[10],
                       sha1 = preservedData[11]
                       )
    temp <- as_tibble(temp) # convert data frame to tidyverse tibble
    temp <- mutate(temp,
                   crawl_date = as.double(crawl_date),
                   last_modified_date = as.double(last_modified_date),
                   width = as.double(width),
                   height = as.double(height)
                   ) # correct data types
    
    # Step 2: rename column names to the real ones
    imageInformation <- rename(imageInformation,
                               crawl_date = 1,
                               last_modified_date = 2,
                               url = 3,
                               filename = 4,
                               extension = 5,
                               mime_type_web_server = 6,
                               mime_type_tika = 7,
                               width = 8,
                               height = 9,
                               md5 = 10,
                               sha1 = 11
                               )
    
    # Step 3: add current column names as a new row to data frame
    imageInformation <- bind_rows(imageInformation, temp)
  }
  
  # ——————
  # INQUIRY 2a
  # Simple count of how many rows there are
  totalRows <- totalRows + count(imageInformation)
  
  # ——————
  # INQUIRY 2b
  # Count the number of unique images
  # (will be off by at most 13 if image groups are broken across .csv files)
  groupBySource <- imageInformation %>%
    group_by(filename)
  uniqueFiles <- uniqueFiles + nrow(count(groupBySource))
  
  # ——————
  # INQUIRY 2c
  # Track the most commonly used images (take only the top 1000 from each .csv)
  commonImages <- imageInformation %>%
    group_by(filename, extension) %>%
    summarize(total = n()) %>%
    arrange(-total) %>%
    head(1000)
  
  # Add new data to history and combine with previous results
  mostUsedImages <- bind_rows(mostUsedImages, commonImages)
  mostUsedImages <- mostUsedImages %>%
    group_by(filename, extension) %>%
    summarize(total = sum(total))
  
  # ——————
  # INQUIRY 2d
  # Track the quantity of each image format
  commonExtension <- imageInformation %>%
    group_by(extension) %>%
    summarize(total = n())
  
  # Add new data to history and combine with previous results
  mostUsedExtension <- bind_rows(mostUsedExtension, commonExtension)
  mostUsedExtension <- mostUsedExtension %>%
    group_by(extension) %>%
    summarize(total = sum(total))
  
  # ——————
  # INQUIRY 2e
  # Track the most commonly used dimensions
  commonDimensions <- imageInformation %>%
    group_by(width, height) %>%
    summarize(total = n()) %>%
    arrange(-total)
    
  # Add new data to history and combine with previous results
  mostUsedDimensions <- bind_rows(mostUsedDimensions, commonDimensions)
  mostUsedDimensions <- mostUsedDimensions %>%
    group_by(width, height) %>%
    summarize(total = sum(total))
}

# Track the end time
endTime <- Sys.time()
timeTaken <- round(endTime - startTime, 2)
timeTaken # 27.78 mins

# Output results
totalRows # 121,384,234
uniqueFiles # 65,212,110

# Create CSVs from created data frames
mostUsedImages
mostUsedExtension
mostUsedDimensions

imagesArranged <- arrange(mostUsedImages, -total)
extensionArranged <- arrange(mostUsedExtension, -total)
dimensionsArranged <- arrange(mostUsedDimensions, -total)

write_csv(imagesArranged, "most-used-images.csv")
write_csv(extensionArranged, "most-used-extension.csv")
write_csv(dimensionsArranged, "most-used-dimensions.csv")


# —————————————————————————————————
# FOLLOW-UPS
# —————————————————————————————————
# Reading the data back in from saved files in case R Studio was closed
exploration2Images <- read_csv("most-used-images.csv")
exploration2Extension <- read_csv("most-used-extension.csv")
exploration2Dimensions <- read_csv("most-used-dimensions.csv")

# Looking at the images data
exploration2ImagesChart <- head(exploration2Images, 100) %>%
  ggplot(aes(x = total, y = fct_reorder(filename, total))) +
  geom_col()
exploration2ImagesChart
# Top 3: serv, visit.gif, counter.gif
# Let’s remove the top two results just to get a better sense of the data
exploration2ImagesChart2 <- head(exploration2Images[c(-1, -2),], 100) %>%
  ggplot(aes(x = total, y = fct_reorder(filename, total))) +
  geom_col()
exploration2ImagesChart2
# Nice curve!
# Could be fun to do another search for just backgrounds or favicons
# Basically just see what the varieties are for images with generic names

# Looking at the extension data
exploration2ExtensionChart <- exploration2Extension %>%
  ggplot(aes(x = total, y = NA, fill = fct_reorder(extension, total))) +
  geom_col(position = "fill") +
  coord_polar() +
  theme_void()
exploration2ExtensionChart
# Pretty overwhelming results with just JPEG and GIF
# Let’s see the value for the remaining file types
notJpgOrGif <- exploration2Extension %>%
  filter(extension != "jpg" & extension != "gif") %>%
  summarize(sum(total))
# 62937182 jpg
# 56553910 gif
# 1893142 non-gif or jpg
# Total: 121384234


# Looking at dimensions data
# Can’t plot as is because currently 1,230,393
# Let’s just look at the top results
exploration2DimensionsChart <- head(exploration2Dimensions, 1000) %>%
  ggplot(aes(x = width, y = height, size = total)) +
  geom_point()
exploration2DimensionsChart
# Actually that’s super cool, shows the consistent aspect ratios and the rarity of larger file sizes
# Just for fun, can we chart more?
exploration2DimensionsChart2 <- head(exploration2Dimensions, 100000) %>%
  ggplot(aes(x = width, y = height, size = total)) +
  geom_point()
exploration2DimensionsChart2
# Ah!! An extreme outlier at 25000 pixels tall!
# OK, new idea with the images
# Our goal is to create a graphic that has each image represent 100 instances of that image
# And we’ll filter out 1,1 because it's makign the data hard to look at
exploration2DimensionsChart3 <- exploration2Dimensions %>%
  filter(width > 1, height > 1, total >= 2000, width <= 1000, height <= 1000) %>%
  mutate(perBucket = cut(total, breaks = c(-1, 100000, 1000000, 1000000000))) %>%
  ggplot(aes(x = width, y = height, alpha = total, size = total, color = perBucket)) +
  scale_fill_brewer(type = "seq", palette = "RdPu") + # red purple (found on colorbrewer2.org)
  geom_point()
exploration2DimensionsChart3


# ——————————————————————————————————————————————————————————————————————————————
# ——————————————————————————————————————————————————————————————————————————————
# EXPLORATION 3:
# WEBGRAPH EXPLORATIONS

# Go through all .csv files and collect the following info:
# 3a. How many rows are we working with in total?
# 3b. How many unique URLs are there for source sites?
# 3c. What are the most commonly used target/anchor text combos?
# ——————————————————————————————————————————————————————————————————————————————
# ——————————————————————————————————————————————————————————————————————————————


# Track the start time
startTime <- Sys.time()

# Initialize tracking variables
totalRows <- 0
uniqueSites <- 0
commonCombos <- data.frame(target = character(),
                           anchor_text = character(),
                           total = integer())

for (x in 0:134) {
  # Read the next relevant .csv file (135 total)
  filename <- paste("derivatives/webgraph/webgraph", x, ".csv", sep="")
  print(filename)
  webgraph <- read_csv(filename)
  
  if (x > 0) {
    # For .csv file after 0, the column names are wrong
    
    # Step 1: create temp data frame with just column names to preserve data
    preservedData <- colnames(webgraph)
    temp <- data.frame(crawl_date = preservedData[1],
                       source = preservedData[2],
                       target = preservedData[3],
                       anchor_text = preservedData[4])
    temp <- as_tibble(temp) # convert data frame to tidyverse tibble
    temp <- mutate(temp, crawl_date = as.double(crawl_date)) # correct data type
    
    # Step 2: rename column names to the real ones
    webgraph <- rename(webgraph, crawl_date = 1, source = 2, target = 3, anchor_text = 4)
    
    # Step 3: add current column names as a new row to data frame
    webgraph <- bind_rows(webgraph, temp)
  }

  # ——————
  # INQUIRY 3a
  # Simple count of how many rows there are
  totalRows <- totalRows + count(webgraph)
  
  # ——————
  # INQUIRY 3b
  # Count of how many unique URLs are represented for source sites
  # Not perfect since this doesn’t account for data across .csv files
  # Good enough though! Should only be off by at most 135 in the end most likely
  groupBySource <- webgraph %>%
    group_by(source)
  uniqueSites <- uniqueSites + nrow(count(groupBySource))
  
  # ——————
  # INQUIRY 3c
  # Track most used [target, anchor_text] combinations and take the top 1000
  mostUsedCombos <- webgraph %>%
    group_by(target, anchor_text) %>%
    summarize(total = n()) %>%
    arrange(-total) %>%
    head(1000)

  # Add new data to history and combine with previous results
  commonCombos <- bind_rows(commonCombos, mostUsedCombos)
  commonCombos <- commonCombos %>%
    group_by(target, anchor_text) %>%
    summarize(total = sum(total))
}

# Track the end time
endTime <- Sys.time()
timeTaken <- round(endTime - startTime, 2)
timeTaken # 2.2 hours

# Output results
totalRows # 1,345,729,749
uniqueSites # 53,478,277
commonCombosArranged <- arrange(commonCombos, -total)
write_csv(commonCombosArranged, "common-combos.csv")


# —————————————————————————————————
# FOLLOW-UPS
# —————————————————————————————————

# Which targets were the most popular overall?
mostPopularTargets <- commonCombosArranged %>%
  group_by(target) %>%
  summarize(total = sum(total)) %>%
  arrange(-total)
mostPopularTargets

# Let’s look at the combos
combosChart <- head(mostPopularTargets, 50) %>%
  ggplot(aes(x = total, y = fct_reorder(target, total))) +
  geom_col()
# scale_y_discrete(label = function(x) stringr::str_trunc(x, 50) )
combosChart